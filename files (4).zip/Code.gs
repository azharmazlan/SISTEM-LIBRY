/*******************************************************************************
 * Sistem Pengurusan Alamanda — Code.gs
 * Backend Google Apps Script (Web App) + Google Sheets sebagai pangkalan data.
 *
 * CARA GUNA:
 * 1. Buka Google Sheets baharu -> Extensions -> Apps Script.
 * 2. Padam kod contoh, tampal KESELURUHAN fail ini sebagai Code.gs.
 * 3. Tampal juga kandungan appsscript.json (Project Settings -> tunjukkan
 *    fail appsscript.json) jika mahu tetapan yang sama.
 * 4. Deploy -> New deployment -> Web app.
 *      - Execute as: Me
 *      - Who has access: Anyone
 * 5. Salin URL Web App yang dihasilkan, tampal ke pembolehubah SCRIPT_URL
 *    dalam script.js (frontend).
 * 6. Sheet-sheet yang diperlukan (Members, Sessions, PointHistory, Payments,
 *    Loans, BulkAttendance) akan dicipta SECARA AUTOMATIK dengan header yang
 *    betul apabila fungsi pertama dipanggil — tidak perlu buat manual.
 * 7. Kata laluan admin lalai ialah "admin123". Untuk menukarnya: Project
 *    Settings -> Script Properties -> tambah kunci ADMIN_PASSWORD.
 ******************************************************************************/

/* ============================== CONFIG ================================== */
const CONFIG = {
  TIMEZONE: 'Asia/Kuala_Lumpur',
  DEFAULT_ADMIN_PASSWORD: 'admin123',
  AHLI_POINTS_PER_VISIT: 10,        // point diberi kepada 'ahli' setiap kali selesai satu sesi (checkout)
  BERTUGAS_MIN_MINUTES: 20,         // >= ini = 'selesai', < ini = 'keluar_awal'
  FINE_PER_DAY: 0.50,               // RM denda automatik setiap hari lewat pulang buku
  ADMIN_SESSION_SECONDS: 6 * 60 * 60 // token admin sah selama 6 jam
};

const SHEETS = {
  MEMBERS: 'Members',
  SESSIONS: 'Sessions',
  POINT_HISTORY: 'PointHistory',
  PAYMENTS: 'Payments',
  LOANS: 'Loans',
  BULK_ATTENDANCE: 'BulkAttendance'
};

const HEADERS = {
  Members: ['id','nfc_id','ic_number','name','category','role','kelas','batch','kategori_peranan','points','created_at','expiry_date'],
  Sessions: ['id','member_id','name','category','role','check_in','check_out','date','status','duration','points_earned'],
  PointHistory: ['id','member_id','action','points','note','date'],
  Payments: ['id','member_id','type','amount_rm','method','note','date'],
  Loans: ['id','member_id','borrower_name','ic_number','kelas','book_number','book_title','loan_date','due_date','status','return_date','fine_amount','fine_paid','extend_date'],
  BulkAttendance: ['id','ic_number','name','kelas','date','time']
};

/* ============================ ENTRY POINTS =============================== */

function doGet(e) {
  try {
    const action = e.parameter.action || '';
    if (action === 'admin_download_excel') {
      return handleDownloadExcel(e.parameter);
    }
    return ContentService.createTextOutput(JSON.stringify({ success: true, message: 'Alamanda API sedia.' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput('Ralat: ' + err.message).setMimeType(ContentService.MimeType.TEXT);
  }
}

function doPost(e) {
  let payload;
  try {
    payload = JSON.parse(e.postData.contents);
  } catch (err) {
    return jsonOut({ success: false, message: 'Payload tidak sah' });
  }

  const path = payload.path || '';
  const method = (payload.method || 'GET').toUpperCase();
  const params = payload.params || {};
  const body = payload.body || {};
  const adminToken = payload.adminToken || '';

  try {
    const result = routeRequest(path, method, params, body, adminToken);
    return jsonOut(result);
  } catch (err) {
    return jsonOut({ success: false, message: 'Ralat server: ' + err.message });
  }
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ============================== ROUTER ==================================== */

function routeRequest(path, method, params, body, adminToken) {
  switch (path) {
    // ---------- DASHBOARD / SCAN ----------
    case 'scan': return handleScan(body);
    case 'today_sessions': return getTodaySessions();
    case 'leaderboard': return getLeaderboard();
    case 'batch_activity': return getBatchActivity();

    // ---------- MEMBERS ----------
    case 'members': return getMembers();
    case 'register': return handleRegister(body);
    case 'get_member_by_nfc': return getMemberByNfc(body.nfc_id);
    case 'find_by_ic': return findByIc(body.ic_number);
    case 'find_by_nfc_assign': return findByNfcAssign(body.nfc_id);
    case 'assign_nfc': return handleAssignNfc(body);
    case 'update_member_individual': return handleUpdateMemberIndividual(body);
    case 'point_history': return getPointHistory(params.id);

    // ---------- BULK (KEMASKINI KELAS SEKALIGUS) ----------
    case 'bulk_members_by_batch': return getBulkMembersByBatch(body.batch, body.course);
    case 'bulk_update_kelas': return bulkUpdateKelas(body.batch, body.course, body.new_kelas);
    case 'bulk_register': return handleBulkRegister(body);

    // ---------- KEHADIRAN IC / BULK ----------
    case 'bulk_attendance/checkin': return bulkAttendanceCheckin(body.ic_number);
    case 'bulk_attendance/list': return getBulkAttendanceList();

    // ---------- PAYMENT / TOPUP ----------
    case 'payment': return handlePayment(body);
    case 'topup': return handleTopup(body);

    // ---------- BOOK LOAN ----------
    case 'book_loan/check_nfc': return loanCheckNfc(body.nfc_id);
    case 'book_loan/check_ic': return loanCheckIc(body.ic_number);
    case 'book_loan/borrow': return loanBorrow(body);
    case 'book_loan/check_return': return loanCheckReturn(body);
    case 'book_loan/return': return loanReturn(body);
    case 'book_loan/pay_fine': return loanPayFine(body);
    case 'book_loan/active_loans': return getActiveLoans();
    case 'book_loan/top_borrowers': return getTopBorrowers(params.month);

    // ---------- ADMIN ----------
    case 'admin/login': return adminLogin(body.password);
    case 'admin/logout': return adminLogout(adminToken);
    case 'admin/check': return adminCheck(adminToken);
    case 'admin/delete_by_batch':
      requireAdmin(adminToken);
      return adminDeleteByBatch(body.batch);
    case 'admin/adjust_points':
      requireAdmin(adminToken);
      return adminAdjustPoints(body);
    case 'admin/delete_member':
      requireAdmin(adminToken);
      return adminDeleteMember(params.id);
    case 'admin/delete_by_month':
      requireAdmin(adminToken);
      return adminDeleteByMonth(body.category, body.month);
    case 'admin/set_expiry':
      requireAdmin(adminToken);
      return adminSetExpiry(body.member_id, body.expiry_date);
    case 'admin/bertugas_list': return getBertugasList();

    default:
      return { success: false, message: 'Laluan API tidak dikenali: ' + path };
  }
}

/* ============================= UTILITIES =================================== */

function ss() { return SpreadsheetApp.getActiveSpreadsheet(); }

function getSheet(name) {
  let sh = ss().getSheetByName(name);
  if (!sh) {
    sh = ss().insertSheet(name);
    sh.appendRow(HEADERS[name]);
    sh.setFrozenRows(1);
  }
  return sh;
}

function sheetToObjects(sh) {
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  const out = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (row.every(c => c === '')) continue;
    const obj = {};
    headers.forEach((h, idx) => obj[h] = row[idx]);
    out.push(obj);
  }
  return out;
}

function nextId(sh) {
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return 1;
  const ids = sh.getRange(2, 1, lastRow - 1, 1).getValues().flat().filter(v => v !== '').map(Number);
  if (!ids.length) return 1;
  return Math.max.apply(null, ids) + 1;
}

function findRowIndexById(sh, id) {
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(id)) return i + 1; // 1-indexed row number
  }
  return -1;
}

function colIndex(sheetName, field) {
  return HEADERS[sheetName].indexOf(field); // 0-indexed
}

function updateCell(sh, sheetName, rowIndex, field, value) {
  const c = colIndex(sheetName, field);
  if (c === -1) return;
  sh.getRange(rowIndex, c + 1).setValue(value);
}

function todayStr() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd'); }
function timeStr() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'HH:mm'); }
function monthStr(dateObj) { return Utilities.formatDate(dateObj, CONFIG.TIMEZONE, 'yyyy-MM'); }

function parseDateOnly(str) {
  // str format: yyyy-MM-dd -> Date object at local midnight
  if (!str) return null;
  const parts = String(str).split('-');
  return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
}

function daysBetween(a, b) {
  return Math.round((a.getTime() - b.getTime()) / (1000 * 60 * 60 * 24));
}

function computeRemainingDisplay(expiryDate) {
  if (!expiryDate) return '';
  const today = parseDateOnly(todayStr());
  const exp = parseDateOnly(expiryDate);
  if (!exp) return '';
  const diff = daysBetween(exp, today);
  if (diff < 0) return 'Tamat tempoh';
  if (diff === 0) return 'Tamat hari ini';
  return diff + ' hari lagi';
}

function computeAutoLogoutLabel(checkinDate) {
  const hour = checkinDate.getHours();
  if (hour < 12) return '13:00 (1:00 PTG)';
  if (hour < 16) return '17:00 (5:00 PTG)';
  return '00:00 (12:00 TENGAH MALAM)';
}

function memberIsActiveToday(memberId) {
  const sh = getSheet(SHEETS.SESSIONS);
  const data = sheetToObjects(sh);
  const today = todayStr();
  return data.some(s => String(s.member_id) === String(memberId) && s.date === today && !s.check_out);
}

function findMemberRow(field, value) {
  const sh = getSheet(SHEETS.MEMBERS);
  const rows = sheetToObjects(sh);
  return rows.find(m => String(m[field]) === String(value));
}

function memberToClientObject(m) {
  return {
    id: m.id,
    nfc_id: m.nfc_id,
    ic_number: m.ic_number,
    name: m.name,
    category: m.category,
    role: m.role,
    kelas: m.kelas,
    batch: m.batch,
    kategori_peranan: m.kategori_peranan,
    points: Number(m.points) || 0,
    created_at: m.created_at,
    expiry_date: m.expiry_date || '',
    remaining: computeRemainingDisplay(m.expiry_date),
    is_active: memberIsActiveToday(m.id)
  };
}

/* ============================== ADMIN AUTH ================================= */

function isAdminValid(token) {
  if (!token) return false;
  const cache = CacheService.getScriptCache();
  return cache.get('admin_' + token) === 'valid';
}

function requireAdmin(token) {
  if (!isAdminValid(token)) {
    throw new Error('Akses admin diperlukan. Sila log masuk semula.');
  }
}

function adminLogin(password) {
  const props = PropertiesService.getScriptProperties();
  const correctPassword = props.getProperty('ADMIN_PASSWORD') || CONFIG.DEFAULT_ADMIN_PASSWORD;
  if (String(password) !== String(correctPassword)) {
    return { success: false, message: 'Kata laluan salah' };
  }
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('admin_' + token, 'valid', CONFIG.ADMIN_SESSION_SECONDS);
  return { success: true, message: 'Log masuk berjaya', token: token };
}

function adminLogout(token) {
  if (token) CacheService.getScriptCache().remove('admin_' + token);
  return { success: true, message: 'Log keluar berjaya' };
}

function adminCheck(token) {
  return { logged_in: isAdminValid(token) };
}

/* ============================== SCAN / SESSIONS ============================= */

function handleScan(body) {
  const nfcId = (body.nfc_id || '').trim();
  if (!nfcId) return { success: false, message: 'Sila imbas atau masukkan ID kad' };

  const member = findMemberRow('nfc_id', nfcId);
  if (!member) return { success: false, message: 'Kad tidak dikenali. Sila daftar dahulu.' };

  const sessSheet = getSheet(SHEETS.SESSIONS);
  const sessions = sheetToObjects(sessSheet);
  const today = todayStr();
  const openSession = sessions.find(s => String(s.member_id) === String(member.id) && s.date === today && !s.check_out);

  const now = new Date();
  const nowTime = timeStr();

  if (openSession) {
    // CHECKOUT
    const rowIdx = findRowIndexById(sessSheet, openSession.id);
    const checkinDate = parseCheckinDateTime(openSession.date, openSession.check_in);
    const duration = Math.max(0, Math.round((now.getTime() - checkinDate.getTime()) / 60000));
    updateCell(sessSheet, SHEETS.SESSIONS, rowIdx, 'check_out', nowTime);
    updateCell(sessSheet, SHEETS.SESSIONS, rowIdx, 'duration', duration);

    let statusType, message, pointsEarned = 0, statusVal = '';
    if (member.category === 'bertugas') {
      statusVal = duration >= CONFIG.BERTUGAS_MIN_MINUTES ? 'selesai' : 'keluar_awal';
      statusType = statusVal;
      message = statusVal === 'selesai' ? 'Selesai bertugas. Terima kasih!' : 'Keluar awal direkodkan.';
      updateCell(sessSheet, SHEETS.SESSIONS, rowIdx, 'status', statusVal);
    } else {
      pointsEarned = CONFIG.AHLI_POINTS_PER_VISIT;
      updateCell(sessSheet, SHEETS.SESSIONS, rowIdx, 'points_earned', pointsEarned);
      updateCell(sessSheet, SHEETS.SESSIONS, rowIdx, 'status', 'selesai');
      addPointsToMember(member.id, pointsEarned, 'kehadiran', 'Point kehadiran');
      statusType = 'checkout';
      message = `Log keluar berjaya. +${pointsEarned} pt diberi.`;
    }

    const updatedMember = findMemberRow('id', member.id);
    const mObj = memberToClientObject(updatedMember);
    mObj.duration = duration;
    return { success: true, member: mObj, status_type: statusType, message: message };
  } else {
    // CHECKIN
    const sh = sessSheet;
    const id = nextId(sh);
    sh.appendRow([id, member.id, member.name, member.category, member.role || '', nowTime, '', today, '', '', '']);
    const statusType = member.category === 'ahli' ? 'checkin_ahli' : 'checkin_bertugas';
    const message = member.category === 'ahli' ? 'Log masuk berjaya. Selamat datang!' : 'Log masuk bertugas berjaya.';
    const mObj = memberToClientObject(member);
    return {
      success: true,
      member: mObj,
      status_type: statusType,
      message: message,
      auto_logout: computeAutoLogoutLabel(now)
    };
  }
}

function parseCheckinDateTime(dateStr, timeStr_) {
  const d = parseDateOnly(dateStr);
  const parts = String(timeStr_).split(':');
  d.setHours(Number(parts[0]) || 0, Number(parts[1]) || 0, 0, 0);
  return d;
}

function getTodaySessions() {
  const sh = getSheet(SHEETS.SESSIONS);
  const today = todayStr();
  return sheetToObjects(sh)
    .filter(s => s.date === today)
    .sort((a, b) => String(b.check_in).localeCompare(String(a.check_in)))
    .map(s => ({
      id: s.id,
      member_id: s.member_id,
      name: s.name,
      category: s.category,
      role: s.role,
      check_in: s.check_in,
      check_out: s.check_out,
      date: s.date,
      status: s.status,
      duration: s.duration,
      points_earned: s.points_earned
    }));
}

/* ============================== MEMBERS ===================================== */

function getMembers() {
  const sh = getSheet(SHEETS.MEMBERS);
  return sheetToObjects(sh).map(memberToClientObject);
}

function getMemberByNfc(nfcId) {
  const m = findMemberRow('nfc_id', (nfcId || '').trim());
  if (!m) return { success: false, message: 'Kad tidak dikenali' };
  return { success: true, member: memberToClientObject(m) };
}

function findByIc(icNumber) {
  const m = findMemberRow('ic_number', (icNumber || '').trim());
  if (!m) return { success: false, message: 'No. IC tidak dijumpai dalam sistem' };
  return { success: true, member: memberToClientObject(m) };
}

function findByNfcAssign(nfcId) {
  const m = findMemberRow('nfc_id', (nfcId || '').trim());
  if (!m) return { success: false, message: 'UID ini tidak didaftarkan lagi' };
  return { success: true, member: memberToClientObject(m) };
}

function handleRegister(body) {
  const nfc_id = (body.nfc_id || '').trim();
  const name = (body.name || '').trim();
  const category = body.category;
  const role = body.role || '';
  const ic_number = body.ic_number || '';
  const initial_points = Number(body.initial_points) || 0;
  const expiry_date = body.expiry_date || '';
  const batch = body.batch || '';

  if (!nfc_id || !name || !category) return { success: false, message: 'Sila isi semua maklumat' };

  const sh = getSheet(SHEETS.MEMBERS);
  const existing = findMemberRow('nfc_id', nfc_id);
  if (existing) return { success: false, message: 'ID Kad NFC ini sudah didaftarkan' };

  const id = nextId(sh);
  sh.appendRow([id, nfc_id, ic_number, name, category, role, '', batch, 'pelajar', initial_points, todayStr(), expiry_date]);
  return { success: true, message: 'Pendaftaran berjaya!' };
}

function handleAssignNfc(body) {
  const ic_number = (body.ic_number || '').trim();
  const nfc_id = (body.nfc_id || '').trim();
  const category = body.category || 'ahli';
  const expiry_date = body.expiry_date || '';
  const kelas = body.kelas || '';
  const batch = body.batch || '';
  const kategori_peranan = body.kategori_peranan || 'pelajar';

  if (!ic_number || !nfc_id) return { success: false, message: 'No. IC dan Kad NFC diperlukan' };

  const sh = getSheet(SHEETS.MEMBERS);
  const existing = findMemberRow('ic_number', ic_number);

  if (existing) {
    const rowIdx = findRowIndexById(sh, existing.id);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'nfc_id', nfc_id);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'category', category);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'kelas', kelas);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'batch', batch);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'kategori_peranan', kategori_peranan);
    if (expiry_date) updateCell(sh, SHEETS.MEMBERS, rowIdx, 'expiry_date', expiry_date);
    return { success: true, message: 'Kad NFC berjaya ditetapkan untuk ' + existing.name };
  } else {
    const id = nextId(sh);
    const role = kategori_peranan === 'guru' ? 'Guru' : (kategori_peranan === 'akp' ? 'AKP' : kelas);
    sh.appendRow([id, nfc_id, ic_number, ic_number, category, role, kelas, batch, kategori_peranan, 0, todayStr(), expiry_date]);
    return { success: true, message: 'Ahli baharu didaftarkan & kad ditetapkan' };
  }
}

function handleUpdateMemberIndividual(body) {
  const id = body.id;
  const sh = getSheet(SHEETS.MEMBERS);
  const rowIdx = findRowIndexById(sh, id);
  if (rowIdx === -1) return { success: false, message: 'Ahli tidak dijumpai' };

  if (body.nfc_id) updateCell(sh, SHEETS.MEMBERS, rowIdx, 'nfc_id', body.nfc_id.trim());
  if (body.name) updateCell(sh, SHEETS.MEMBERS, rowIdx, 'name', body.name.trim());
  if (body.kelas !== undefined) {
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'kelas', body.kelas);
    updateCell(sh, SHEETS.MEMBERS, rowIdx, 'role', body.kelas);
  }
  if (body.batch !== undefined) updateCell(sh, SHEETS.MEMBERS, rowIdx, 'batch', body.batch);
  if (body.category) updateCell(sh, SHEETS.MEMBERS, rowIdx, 'category', body.category);

  return { success: true, message: 'Kemaskini berjaya' };
}

function getPointHistory(memberId) {
  const sh = getSheet(SHEETS.POINT_HISTORY);
  return sheetToObjects(sh)
    .filter(h => String(h.member_id) === String(memberId))
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .map(h => ({ action: h.action, points: Number(h.points), note: h.note, date: h.date }));
}

function addPointsToMember(memberId, points, action, note) {
  const sh = getSheet(SHEETS.MEMBERS);
  const rowIdx = findRowIndexById(sh, memberId);
  if (rowIdx === -1) return false;
  const current = Number(sh.getRange(rowIdx, colIndex('Members', 'points') + 1).getValue()) || 0;
  const updated = current + points;
  updateCell(sh, SHEETS.MEMBERS, rowIdx, 'points', updated);

  const histSh = getSheet(SHEETS.POINT_HISTORY);
  const id = nextId(histSh);
  histSh.appendRow([id, memberId, action, points, note, Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm')]);
  return true;
}

/* ============================== LEADERBOARD / BATCH ========================= */

function getLeaderboard() {
  const sh = getSheet(SHEETS.MEMBERS);
  return sheetToObjects(sh)
    .filter(m => m.category === 'ahli')
    .sort((a, b) => (Number(b.points) || 0) - (Number(a.points) || 0))
    .slice(0, 10)
    .map(m => ({ name: m.name, points: Number(m.points) || 0 }));
}

function getBatchActivity() {
  const attSh = getSheet(SHEETS.BULK_ATTENDANCE);
  const memSh = getSheet(SHEETS.MEMBERS);
  const attendance = sheetToObjects(attSh);
  const members = sheetToObjects(memSh);
  const icToBatch = {};
  members.forEach(m => { if (m.ic_number) icToBatch[m.ic_number] = m.batch; });

  const month = monthStr(new Date());
  const counts = {};
  attendance.forEach(a => {
    if (String(a.date || '').indexOf(month) !== 0) return;
    const batch = icToBatch[a.ic_number] || a.kelas || 'Lain-lain';
    if (!batch) return;
    counts[batch] = (counts[batch] || 0) + 1;
  });
  return Object.keys(counts)
    .map(batch => ({ batch: batch, count: counts[batch] }))
    .sort((a, b) => b.count - a.count);
}

/* ============================== BULK UPDATE KELAS ============================ */

function getBulkMembersByBatch(batch, course) {
  if (!batch) return { success: false, message: 'Sila masukkan nombor batch' };
  const sh = getSheet(SHEETS.MEMBERS);
  let members = sheetToObjects(sh).filter(m => String(m.batch) === String(batch) && String(m.nfc_id).indexOf('BULK_') === 0);
  if (course) members = members.filter(m => String(m.kelas || '').toUpperCase().indexOf(String(course).toUpperCase()) !== -1);
  return {
    success: true,
    count: members.length,
    members: members.map(m => ({ id: m.id, name: m.name, ic_number: m.ic_number, kelas: m.kelas, batch: m.batch, category: m.category, nfc_id: m.nfc_id }))
  };
}

function bulkUpdateKelas(batch, course, newKelas) {
  if (!batch || !newKelas) return { success: false, message: 'Sila lengkapkan batch dan kelas baru' };
  const sh = getSheet(SHEETS.MEMBERS);
  const data = sh.getDataRange().getValues();
  const kelasCol = colIndex('Members', 'kelas');
  const batchCol = colIndex('Members', 'batch');
  const nfcCol = colIndex('Members', 'nfc_id');
  let count = 0;
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (String(row[batchCol]) !== String(batch)) continue;
    if (String(row[nfcCol]).indexOf('BULK_') !== 0) continue;
    if (course && String(row[kelasCol] || '').toUpperCase().indexOf(String(course).toUpperCase()) === -1) continue;
    sh.getRange(i + 1, kelasCol + 1).setValue(newKelas);
    count++;
  }
  return { success: true, message: `${count} rekod dikemaskini ke kelas "${newKelas}"` };
}

function handleBulkRegister(body) {
  const rows = body.rows || [];
  const batch = body.batch || '';
  const category = body.category || 'pelajar';
  const expiry_date = body.expiry_date || '';
  if (!rows.length) return { success: false, message: 'Tiada rekod untuk didaftarkan' };

  const sh = getSheet(SHEETS.MEMBERS);
  let id = nextId(sh);
  const newRows = [];
  rows.forEach(r => {
    if (!r.name) return;
    const nfcId = 'BULK_' + Utilities.getUuid();
    newRows.push([id, nfcId, r.ic_number || '', r.name, 'ahli', '', r.kelas || '', batch, category, 0, todayStr(), expiry_date]);
    id++;
  });
  if (newRows.length) {
    sh.getRange(sh.getLastRow() + 1, 1, newRows.length, newRows[0].length).setValues(newRows);
  }
  return { success: true, message: `${newRows.length} ahli berjaya didaftarkan secara sekaligus` };
}

/* ============================== KEHADIRAN IC/BULK ============================ */

function bulkAttendanceCheckin(icNumber) {
  const ic = (icNumber || '').trim();
  if (!ic) return { success: false, message: 'Sila masukkan No. IC' };

  const member = findMemberRow('ic_number', ic);
  if (!member) return { success: false, not_found: true, message: 'IC tidak dijumpai. SILA KE KAUNTER.' };

  const sh = getSheet(SHEETS.BULK_ATTENDANCE);
  const id = nextId(sh);
  const date = todayStr();
  const time = timeStr();
  sh.appendRow([id, ic, member.name, member.kelas || '', date, time]);

  return {
    success: true,
    message: 'Kehadiran berjaya direkod',
    member: { name: member.name, category: member.category, ic_number: ic, kelas: member.kelas || '', date: date, time: time }
  };
}

function getBulkAttendanceList() {
  const sh = getSheet(SHEETS.BULK_ATTENDANCE);
  const today = todayStr();
  return sheetToObjects(sh)
    .filter(r => r.date === today)
    .sort((a, b) => String(b.time).localeCompare(String(a.time)))
    .map(r => ({ name: r.name, ic_number: r.ic_number, kelas: r.kelas, date: r.date, time: r.time }));
}

/* ============================== PAYMENT / TOPUP ============================== */

function handlePayment(body) {
  const memberId = body.member_id;
  const amount = Number(body.amount_rm);
  const method = body.method;
  const note = body.note || '';
  if (!memberId || !amount || amount <= 0) return { success: false, message: 'Data pembayaran tidak lengkap' };

  const paySh = getSheet(SHEETS.PAYMENTS);
  const id = nextId(paySh);

  if (method === 'kad') {
    const memSh = getSheet(SHEETS.MEMBERS);
    const rowIdx = findRowIndexById(memSh, memberId);
    if (rowIdx === -1) return { success: false, message: 'Ahli tidak dijumpai' };
    const currentPoints = Number(memSh.getRange(rowIdx, colIndex('Members', 'points') + 1).getValue()) || 0;
    const ptNeeded = Math.round(amount * 100);
    if (currentPoints < ptNeeded) return { success: false, message: 'Point tidak mencukupi' };
    addPointsToMember(memberId, -ptNeeded, 'bayaran', note || `Bayaran RM${amount.toFixed(2)}`);
  }

  paySh.appendRow([id, memberId, 'payment', amount, method, note, Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm')]);
  return { success: true, message: `Bayaran RM${amount.toFixed(2)} berjaya direkod` };
}

function handleTopup(body) {
  const memberId = body.member_id;
  const amount = Number(body.amount_rm);
  const note = body.note || '';
  if (!memberId || !amount || amount <= 0) return { success: false, message: 'Data tidak lengkap' };

  const ptToAdd = Math.round(amount * 100);
  addPointsToMember(memberId, ptToAdd, 'topup', note || `Tambah nilai RM${amount.toFixed(2)}`);

  const paySh = getSheet(SHEETS.PAYMENTS);
  const id = nextId(paySh);
  paySh.appendRow([id, memberId, 'topup', amount, 'kad', note, Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm')]);
  return { success: true, message: `Tambah nilai RM${amount.toFixed(2)} berjaya (+${ptToAdd} pt)` };
}

/* ============================== BOOK LOAN ==================================== */

function loanCheckNfc(nfcId) {
  const m = findMemberRow('nfc_id', (nfcId || '').trim());
  if (!m) return { success: false, message: 'Kad tidak dikenali' };
  return { success: true, member: { name: m.name, ic_number: m.ic_number, kelas: m.kelas, category: m.category } };
}

function loanCheckIc(icNumber) {
  const ic = (icNumber || '').trim();
  const m = findMemberRow('ic_number', ic);
  if (m) return { success: true, via: 'member', member: { name: m.name, ic_number: m.ic_number, kelas: m.kelas, category: m.category, nfc_id: m.nfc_id } };

  // fallback: cari nama daripada rekod pinjaman lampau dengan IC sama (peminjam bukan ahli)
  const loanSh = getSheet(SHEETS.LOANS);
  const prior = sheetToObjects(loanSh).find(l => l.ic_number === ic);
  if (prior) return { success: true, via: 'ic_only', member: { name: prior.borrower_name, ic_number: ic, kelas: prior.kelas, category: 'bukan_ahli' } };

  return { success: false, message: 'No. IC tidak dijumpai. Sila daftar sebagai ahli/bertugas dahulu, atau isi borang manual.' };
}

function loanBorrow(body) {
  const nfcId = body.nfc_id || '';
  const icNumber = body.ic_number || '';
  const kelas = body.kelas || '';
  const bookNumber = body.book_number || '';
  const bookTitle = body.book_title || '';
  const loanDate = body.loan_date || todayStr();
  const dueDate = body.due_date || '';
  if (!bookNumber || !bookTitle || !loanDate || !dueDate) return { success: false, message: 'Sila lengkapkan maklumat pinjaman' };

  let member = null;
  if (nfcId && nfcId.indexOf('IC_') !== 0) member = findMemberRow('nfc_id', nfcId);
  if (!member && icNumber) member = findMemberRow('ic_number', icNumber);

  const borrowerName = member ? member.name : (icNumber ? icNumber : 'Peminjam');

  const sh = getSheet(SHEETS.LOANS);
  const id = nextId(sh);
  sh.appendRow([id, member ? member.id : '', borrowerName, icNumber, kelas, bookNumber, bookTitle, loanDate, dueDate, 'active', '', 0, false, '']);
  return { success: true, message: 'Pinjaman berjaya direkod' };
}

function loanCheckReturn(body) {
  const nfcId = (body.nfc_id || '').trim();
  const icNumber = (body.ic_number || '').trim();

  let member = null;
  if (nfcId) member = findMemberRow('nfc_id', nfcId);
  if (!member && icNumber) member = findMemberRow('ic_number', icNumber);

  const resolvedIc = member ? member.ic_number : icNumber;
  if (!member && !resolvedIc) return { success: false, message: 'Ahli/kad tidak dikenali' };

  const loanSh = getSheet(SHEETS.LOANS);
  const allLoans = sheetToObjects(loanSh).filter(l => l.status === 'active');
  const loans = allLoans.filter(l => (member && String(l.member_id) === String(member.id)) || (resolvedIc && l.ic_number === resolvedIc));

  if (!loans.length) return { success: false, message: 'Tiada pinjaman aktif dijumpai untuk kad/IC ini' };

  const today = parseDateOnly(todayStr());
  const result = loans.map(l => {
    const due = parseDateOnly(l.due_date);
    const daysLate = Math.max(0, daysBetween(today, due));
    const autoFine = Math.round(daysLate * CONFIG.FINE_PER_DAY * 100) / 100;
    return { id: l.id, book_title: l.book_title, book_number: l.book_number, loan_date: l.loan_date, due_date: l.due_date, days_late: daysLate, auto_fine: autoFine };
  });

  return { success: true, member_name: member ? member.name : (loans[0].borrower_name || resolvedIc), loans: result };
}

function loanReturn(body) {
  const loanId = body.loan_id;
  const action = body.action; // 'ada' | 'tiada' | 'lanjut'
  const sh = getSheet(SHEETS.LOANS);
  const rowIdx = findRowIndexById(sh, loanId);
  if (rowIdx === -1) return { success: false, message: 'Rekod pinjaman tidak dijumpai' };

  if (action === 'ada') {
    updateCell(sh, SHEETS.LOANS, rowIdx, 'status', 'returned');
    updateCell(sh, SHEETS.LOANS, rowIdx, 'return_date', todayStr());
    if (body.fine_amount) updateCell(sh, SHEETS.LOANS, rowIdx, 'fine_amount', Number(body.fine_amount));
    return { success: true, message: 'Buku berjaya dipulangkan' };
  } else if (action === 'tiada') {
    updateCell(sh, SHEETS.LOANS, rowIdx, 'status', 'lost');
    updateCell(sh, SHEETS.LOANS, rowIdx, 'return_date', todayStr());
    updateCell(sh, SHEETS.LOANS, rowIdx, 'fine_amount', Number(body.fine_amount) || 0);
    return { success: true, message: 'Direkodkan sebagai hilang/rosak' };
  } else if (action === 'lanjut') {
    const extendDate = body.extend_date;
    if (!extendDate) return { success: false, message: 'Sila pilih tarikh lanjutan' };
    updateCell(sh, SHEETS.LOANS, rowIdx, 'due_date', extendDate);
    updateCell(sh, SHEETS.LOANS, rowIdx, 'extend_date', extendDate);
    return { success: true, message: 'Tempoh pinjaman berjaya dilanjutkan' };
  }
  return { success: false, message: 'Tindakan tidak sah' };
}

function loanPayFine(body) {
  const loanId = body.loan_id;
  const method = body.method;
  const fine = Number(body.fine_amount) || 0;
  if (!loanId || fine <= 0) return { success: false, message: 'Data denda tidak lengkap' };

  const loanSh = getSheet(SHEETS.LOANS);
  const rowIdx = findRowIndexById(loanSh, loanId);
  if (rowIdx === -1) return { success: false, message: 'Pinjaman tidak dijumpai' };

  const paySh = getSheet(SHEETS.PAYMENTS);
  let memberIdForPayment = '';

  if (method === 'kad') {
    const nfcId = (body.nfc_id || '').trim();
    const member = findMemberRow('nfc_id', nfcId);
    if (!member) return { success: false, message: 'Kad ahli tidak dikenali' };
    const ptNeeded = Math.round(fine * 100);
    if ((Number(member.points) || 0) < ptNeeded) return { success: false, message: 'Point tidak mencukupi, guna tunai' };
    addPointsToMember(member.id, -ptNeeded, 'denda', `Bayaran denda RM${fine.toFixed(2)}`);
    memberIdForPayment = member.id;
  }

  updateCell(loanSh, SHEETS.LOANS, rowIdx, 'fine_paid', true);
  updateCell(loanSh, SHEETS.LOANS, rowIdx, 'fine_amount', fine);

  const id = nextId(paySh);
  paySh.appendRow([id, memberIdForPayment, 'fine', fine, method, 'Denda lewat pulang buku', Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm')]);

  return { success: true, message: `Denda RM${fine.toFixed(2)} berjaya dibayar` };
}

function getActiveLoans() {
  const sh = getSheet(SHEETS.LOANS);
  const today = parseDateOnly(todayStr());
  return sheetToObjects(sh).filter(l => l.status === 'active').map(l => {
    const due = parseDateOnly(l.due_date);
    const daysLeft = daysBetween(due, today) * -1; // positive = days remaining, negative = late
    const isLate = daysLeft < 0;
    const fine = isLate ? Math.round(Math.abs(daysLeft) * CONFIG.FINE_PER_DAY * 100) / 100 : 0;
    return {
      id: l.id,
      borrower_name: l.borrower_name,
      kelas: l.kelas,
      book_title: l.book_title,
      book_number: l.book_number,
      loan_date: l.loan_date,
      due_date: l.due_date,
      days_left: daysLeft,
      is_late: isLate,
      fine: fine
    };
  });
}

function getTopBorrowers(month) {
  const targetMonth = month || monthStr(new Date());
  const sh = getSheet(SHEETS.LOANS);
  const loans = sheetToObjects(sh).filter(l => String(l.loan_date || '').indexOf(targetMonth) === 0);
  const counts = {};
  loans.forEach(l => {
    const key = l.ic_number || l.borrower_name;
    if (!counts[key]) counts[key] = { name: l.borrower_name, kelas: l.kelas, total: 0 };
    counts[key].total++;
  });
  return Object.values(counts).sort((a, b) => b.total - a.total).slice(0, 5);
}

/* ============================== ADMIN ACTIONS ================================ */

function adminDeleteByBatch(batch) {
  if (!batch) return { success: false, message: 'Sila masukkan nombor batch' };
  const sh = getSheet(SHEETS.MEMBERS);
  const data = sh.getDataRange().getValues();
  const batchCol = colIndex('Members', 'batch');
  let count = 0;
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][batchCol]) === String(batch)) {
      sh.deleteRow(i + 1);
      count++;
    }
  }
  return { success: true, message: `${count} ahli dalam batch "${batch}" telah dipadam` };
}

function adminAdjustPoints(body) {
  const memberId = body.member_id;
  const action = body.action; // 'tambah' | 'tebus'
  const points = Number(body.points);
  const note = body.note || '';
  if (!memberId || !points || points < 1) return { success: false, message: 'Sila masukkan jumlah point yang sah' };

  const delta = action === 'tebus' ? -points : points;
  const sh = getSheet(SHEETS.MEMBERS);
  const rowIdx = findRowIndexById(sh, memberId);
  if (rowIdx === -1) return { success: false, message: 'Ahli tidak dijumpai' };
  const current = Number(sh.getRange(rowIdx, colIndex('Members', 'points') + 1).getValue()) || 0;
  if (action === 'tebus' && current < points) return { success: false, message: 'Point ahli tidak mencukupi untuk ditebus' };

  addPointsToMember(memberId, delta, action, note);
  return { success: true, message: 'Point berjaya dikemaskini' };
}

function adminDeleteMember(id) {
  const sh = getSheet(SHEETS.MEMBERS);
  const rowIdx = findRowIndexById(sh, id);
  if (rowIdx === -1) return { success: false, message: 'Ahli tidak dijumpai' };
  sh.deleteRow(rowIdx);
  return { success: true, message: 'Ahli berjaya dibuang' };
}

function adminDeleteByMonth(category, month) {
  if (!month) return { success: false, message: 'Sila pilih bulan' };
  const sh = getSheet(SHEETS.MEMBERS);
  const data = sh.getDataRange().getValues();
  const catCol = colIndex('Members', 'category');
  const createdCol = colIndex('Members', 'created_at');
  let count = 0;
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][catCol]) !== String(category)) continue;
    if (String(data[i][createdCol] || '').indexOf(month) !== 0) continue;
    sh.deleteRow(i + 1);
    count++;
  }
  return { success: true, message: `${count} rekod "${category}" bulan ${month} telah dipadam` };
}

function adminSetExpiry(memberId, expiryDate) {
  const sh = getSheet(SHEETS.MEMBERS);
  const rowIdx = findRowIndexById(sh, memberId);
  if (rowIdx === -1) return { success: false, message: 'Ahli tidak dijumpai' };
  updateCell(sh, SHEETS.MEMBERS, rowIdx, 'expiry_date', expiryDate || '');
  return { success: true, message: 'Tarikh tamat berjaya dikemaskini' };
}

function getBertugasList() {
  const sh = getSheet(SHEETS.MEMBERS);
  const members = sheetToObjects(sh).filter(m => m.category === 'bertugas');
  const courseRegex = /\b(ETN|ETE|MTK|MTA|BAK|BKP|PPU|MPI|CTP)\b/i;
  const list = members.map(m => {
    const kelasUp = String(m.kelas || '').toUpperCase();
    const match = kelasUp.match(courseRegex);
    return {
      id: m.id,
      name: m.name,
      nfc_id: m.nfc_id,
      batch: m.batch,
      kelas: m.kelas || '-',
      course: match ? match[1] : '-',
      kategori: m.kategori_peranan === 'guru' ? 'Guru' : (m.kategori_peranan === 'akp' ? 'AKP' : 'Pelajar'),
      role: m.role
    };
  });
  return { success: true, members: list };
}

/* ============================== EXCEL / CSV DOWNLOAD ========================== */

function csvEscape(v) {
  const s = (v === null || v === undefined) ? '' : String(v);
  if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function rowsToCsv(headerRow, rows) {
  const lines = [headerRow.map(csvEscape).join(',')];
  rows.forEach(r => lines.push(r.map(csvEscape).join(',')));
  return lines.join('\r\n');
}

function handleDownloadExcel(params) {
  const type = params.type || '';
  const month = params.month || '';
  let filename = 'laporan.csv';
  let csv = '';

  if (type === 'ahli_point_attendance') {
    filename = 'ahli_point_attendance.csv';
    const members = sheetToObjects(getSheet(SHEETS.MEMBERS)).filter(m => m.category === 'ahli' && (!month || String(m.created_at).indexOf(month) === 0));
    csv = rowsToCsv(['Nama', 'No. IC', 'Kelas', 'Batch', 'Point', 'Tarikh Daftar'],
      members.map(m => [m.name, m.ic_number, m.kelas, m.batch, m.points, m.created_at]));
  } else if (type === 'ahli_nfc') {
    filename = 'ahli_nfc.csv';
    const members = sheetToObjects(getSheet(SHEETS.MEMBERS)).filter(m => m.category === 'ahli');
    csv = rowsToCsv(['Nama', 'NFC ID', 'No. IC', 'Kelas', 'Batch', 'Point'],
      members.map(m => [m.name, m.nfc_id, m.ic_number, m.kelas, m.batch, m.points]));
  } else if (type === 'bertugas') {
    filename = 'laporan_bertugas.csv';
    const sessions = sheetToObjects(getSheet(SHEETS.SESSIONS)).filter(s => s.category === 'bertugas' && (!month || String(s.date).indexOf(month) === 0));
    csv = rowsToCsv(['Nama', 'Tarikh', 'Masuk', 'Keluar', 'Tempoh (minit)', 'Status'],
      sessions.map(s => [s.name, s.date, s.check_in, s.check_out, s.duration, s.status]));
  } else if (type === 'senarai_bertugas') {
    filename = 'senarai_bertugas.csv';
    const members = sheetToObjects(getSheet(SHEETS.MEMBERS)).filter(m => m.category === 'bertugas');
    csv = rowsToCsv(['Nama', 'NFC ID', 'Batch', 'Kelas', 'Kategori/Peranan'],
      members.map(m => [m.name, m.nfc_id, m.batch, m.kelas, m.kategori_peranan]));
  } else if (type === 'pinjaman') {
    filename = 'pinjaman_pemulangan.csv';
    const loans = sheetToObjects(getSheet(SHEETS.LOANS)).filter(l => !month || String(l.loan_date).indexOf(month) === 0);
    csv = rowsToCsv(['Nama Peminjam', 'No. IC', 'Kelas', 'Nombor Buku', 'Tajuk Buku', 'Tarikh Pinjam', 'Tarikh Due', 'Status', 'Tarikh Pulang', 'Denda (RM)'],
      loans.map(l => [l.borrower_name, l.ic_number, l.kelas, l.book_number, l.book_title, l.loan_date, l.due_date, l.status, l.return_date, l.fine_amount]));
  } else if (type === 'bulk_attendance') {
    filename = 'kehadiran_ic.csv';
    const att = sheetToObjects(getSheet(SHEETS.BULK_ATTENDANCE)).filter(a => !month || String(a.date).indexOf(month) === 0);
    csv = rowsToCsv(['Nama', 'No. IC', 'Kelas', 'Tarikh', 'Masa'],
      att.map(a => [a.name, a.ic_number, a.kelas, a.date, a.time]));
  } else {
    csv = 'Jenis laporan tidak sah';
  }

  return ContentService.createTextOutput(csv).setMimeType(ContentService.MimeType.CSV);
}
