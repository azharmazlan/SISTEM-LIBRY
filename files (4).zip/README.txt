SISTEM PENGURUSAN ALAMANDA — PANDUAN DEPLOY
=============================================
(Frontend: GitHub Pages | Backend: Google Apps Script | Database: Google Sheets)


STRUKTUR FAIL
-------------
index.html            -> Struktur halaman (HTML)
style.css              -> Reka bentuk / gaya (CSS) — tidak diubah daripada asal
script.js               -> Semua logik (JavaScript) — fungsi asal dikekalkan 100%
manifest.json          -> Konfigurasi PWA (Install App)
service-worker.js      -> Cache app-shell untuk PWA
icons/                  -> Ikon aplikasi (favicon, apple-touch-icon, ikon PWA)
Code.gs                 -> Backend API (Google Apps Script)
appsscript.json         -> Tetapan projek Apps Script
README.txt              -> Fail ini


BAHAGIAN A — SEDIAKAN BACKEND (GOOGLE APPS SCRIPT + GOOGLE SHEETS)
--------------------------------------------------------------------
1. Pergi ke https://sheets.google.com dan cipta Google Sheet BAHARU (kosong).
   Namakan contohnya "Database Alamanda".

2. Dalam Google Sheet tersebut, klik menu:
   Extensions (Sambungan) -> Apps Script

3. Akan terbuka editor Apps Script dengan fail "Code.gs" (kosong / contoh).
   PADAM semua kandungan lalai, dan TAMPAL keseluruhan kandungan fail
   "Code.gs" (dalam pek ini) ke dalamnya.

4. (Pilihan) Klik ikon gear "Project Settings" di editor Apps Script ->
   tandakan "Show appsscript.json manifest file in editor" -> buka fail
   appsscript.json yang terhasil -> gantikan kandungannya dengan fail
   "appsscript.json" dalam pek ini.

5. SIMPAN (Ctrl+S / Cmd+S).

6. Klik butang "Deploy" (biru, kanan atas) -> "New deployment".
   - Klik ikon gear di sebelah "Select type" -> pilih "Web app".
   - Description: "Alamanda API v1" (bebas)
   - Execute as: "Me (emel anda)"
   - Who has access: "Anyone"
   - Klik "Deploy".
   - Google mungkin minta kebenaran (Authorize access) — ikut langkah,
     pilih akaun anda, klik "Advanced" -> "Go to (nama projek) (unsafe)"
     jika keluar amaran (ini normal untuk skrip sendiri) -> "Allow".

7. Selepas deploy berjaya, SALIN "Web app URL" yang diberikan.
   Formatnya seperti:
   https://script.google.com/macros/s/AKfycbxxxxxxxxxxxxxxxxxxxx/exec

8. Sheet-sheet yang diperlukan (Members, Sessions, PointHistory, Payments,
   Loans, BulkAttendance) akan DICIPTA SECARA AUTOMATIK berserta header
   yang betul apabila fungsi backend pertama dipanggil (contohnya semasa
   frontend memuatkan senarai ahli buat kali pertama). Tidak perlu buat
   sheet secara manual.

9. TUKAR KATA LALUAN ADMIN (disyorkan):
   - Dalam editor Apps Script -> Project Settings (ikon gear) ->
     "Script Properties" -> "Add script property".
   - Property: ADMIN_PASSWORD
   - Value: (kata laluan admin pilihan anda)
   - Simpan. (Jika tidak ditetapkan, kata laluan lalai ialah: admin123)


BAHAGIAN B — SAMBUNGKAN FRONTEND KE BACKEND
---------------------------------------------
1. Buka fail "script.js" (dalam pek ini) menggunakan editor teks.

2. Cari baris di bahagian paling atas:

       const SCRIPT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";

3. Gantikan teks placeholder dengan URL Web App yang disalin pada
   Bahagian A, langkah 7. Contoh:

       const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxxxxx/exec";

4. Simpan fail. INI SAHAJA satu-satunya tempat yang perlu ditukar jika
   URL Web App berubah pada masa hadapan (contohnya selepas "New
   deployment" versi baharu).


BAHAGIAN C — HOS DI GITHUB PAGES
------------------------------------
1. Cipta repositori GitHub baharu (contoh: "sistem-alamanda").

2. Muat naik SEMUA fail berikut ke root repositori tersebut:
   - index.html
   - style.css
   - script.js
   - manifest.json
   - service-worker.js
   - folder icons/ (dengan semua fail di dalamnya)
   (Fail Code.gs, appsscript.json dan README.txt TIDAK perlu dimuat naik
   ke GitHub — ia hanya untuk Google Apps Script / rujukan.)

3. Pergi ke Settings (repositori) -> Pages.
   - Source: "Deploy from a branch"
   - Branch: pilih "main" (atau "master"), folder "/ (root)"
   - Klik Save.

4. Tunggu 1-2 minit. GitHub akan memberikan URL laman web anda, contoh:
   https://<username-anda>.github.io/sistem-alamanda/

5. Buka URL tersebut — sistem akan berfungsi sepenuhnya, disambungkan
   terus ke Google Sheets melalui Google Apps Script.


BAHAGIAN D — PASANG SEBAGAI APLIKASI (PWA)
----------------------------------------------
Sistem ini sudah PWA-ready. TIADA popup/pop-up automatik akan dipaparkan
oleh sistem — pemasangan dilakukan melalui fungsi biasa pelayar:

- Android (Chrome): Menu (⋮) -> "Install app" / "Add to Home screen".
- iPhone/iPad (Safari): Butang Share (kotak + anak panah) ->
  "Add to Home Screen".
- Windows / macOS / Desktop (Chrome/Edge): Ikon "Install" (⊕) akan
  muncul di hujung kanan bar alamat (address bar) — klik untuk pasang.

Ikon aplikasi (logo KV) akan dipaparkan secara automatik pada semua
platform di atas.

NOTA PENTING TENTANG LOGO:
Disebabkan sekatan rangkaian semasa penjanaan pek ini, logo KV asal
(dimuat naik daripada pautan Google gstatic) tidak dapat dimuat turun
secara automatik. Fail dalam folder icons/ pada masa ini ialah ikon
placeholder bertema "KV" yang dijana secara program (menggunakan warna
sistem sedia ada). UNTUK MENGGANTIKAN DENGAN LOGO SEBENAR:
1. Simpan fail logo KV sebenar anda (format PNG, disyorkan sekurang-
   kurangnya 512x512px, latar belakang lutsinar/telus).
2. Gantikan fail-fail berikut dengan versi logo sebenar (kekalkan nama
   fail & saiz yang sama, atau gunakan mana-mana alat percuma seperti
   https://realfavicongenerator.net untuk menjana semua saiz sekaligus):
     icons/favicon-16.png   (16x16)
     icons/favicon-32.png   (32x32)
     icons/apple-touch-icon.png (180x180)
     icons/icon-192.png     (192x192)
     icons/icon-512.png     (512x512)
     icons/icon-maskable-512.png (512x512, dengan padding ~10% setiap sisi)
3. Muat naik semula ke GitHub Pages — tiada perubahan lain diperlukan.


CATATAN TEKNIKAL / ANDAIAN PERNIAGAAN
-----------------------------------------
Oleh kerana backend asal sistem ini (Node/Flask) tidak disertakan dalam
fail sumber (hanya frontend HTML sedia ada), beberapa peraturan
perniagaan berikut TELAH DITETAPKAN sebagai nilai lalai yang munasabah
dalam Code.gs. Semuanya boleh ditukar dengan mudah di bahagian CONFIG
pada bahagian atas Code.gs:

  - AHLI_POINTS_PER_VISIT = 10   (point diberi kepada "Ahli" bagi setiap
    sesi kehadiran yang selesai/checkout)
  - BERTUGAS_MIN_MINUTES = 20    (tempoh minimum bertugas sebelum
    dianggap "Selesai Bertugas"; kurang daripada ini = "Keluar Awal")
  - FINE_PER_DAY = RM 0.50       (denda automatik setiap hari lewat
    pulangkan buku)
  - Kadar 100 point = RM 1.00 (kekal sepertimana dipaparkan di UI asal)

Sesi log-masuk admin menggunakan token sementara (sah 6 jam) disimpan
dalam CacheService Apps Script + localStorage pelayar — ini menggantikan
mekanisme "cookie session" pelayan asal yang tidak sesuai untuk seni
bina static-frontend + Apps Script.


PENYELESAIAN MASALAH (TROUBLESHOOTING)
-------------------------------------------
- "Ralat sambungan" / data tidak muncul:
  Pastikan SCRIPT_URL dalam script.js telah ditampal dengan betul dan
  deployment Apps Script masih aktif ("Who has access: Anyone").

- Selepas mengedit Code.gs, perubahan tidak nampak di laman web:
  Anda perlu buat "New deployment" baharu (atau "Manage deployments" ->
  edit versi sedia ada -> "New version") setiap kali kod backend
  dikemaskini, supaya URL Web App menggunakan kod terkini.

- Ralat kebenaran (permission) semasa deploy pertama kali:
  Ini normal untuk skrip Apps Script peribadi — klik "Advanced" ->
  "Go to (nama projek) (unsafe)" -> "Allow".
